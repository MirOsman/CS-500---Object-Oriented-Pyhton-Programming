import enum

class BuildingType:
    