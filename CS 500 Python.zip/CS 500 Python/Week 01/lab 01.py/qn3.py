#print the program title
print("the values computing")

n = (input("Input an integer : "))
n1 = int("2" + n + n)
n2 = int("3" + n + n + n)
n3 = int(int(n) + n1 + n2)

# sum = int(n +"2"+(n+n) + "3" +(n+n+n))
print (n3)