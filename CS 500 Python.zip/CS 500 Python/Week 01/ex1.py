#print the program title
print("Finding an average")

#get the user inputs
n1 = int(input("Enter the first number: "))
n2 = int(input("Enter the second number: "))
n3 = int(input("Enter the third number: " ))

print("You entered these numbers:", n1,n2,n3)

#processing the data
sum = n1 + n2 + n3
average = sum / 3

#print the result
print("The average of your number is ", average)