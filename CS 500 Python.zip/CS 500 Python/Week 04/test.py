a : int = 10
b : str = "Peter"
c : list[int] = [5,6,7]


a = "abc"

print(a)