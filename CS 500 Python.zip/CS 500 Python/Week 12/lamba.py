def add(a,b):
   return a + b

sum = (lambda a,b : a+b)(5,6)
print(sum)



