fruits = ["apple","orange","pear","banana"]
lens = list(map(lambda x : x[0], fruits))
print(lens)


# ["a", "o", "p", "b"]